const { useState } = React;
// images from url-website //
const images = [
  { src: 'https://th.bing.com/th/id/OIP.aoGl2DjVsA0S_uY49GMn5QAAAA?rs=1&pid=ImgDetMain', name: 'lake water'  },

  { src: 'https://th.bing.com/th/id/OIP.DhJnLYBysW-09T5w0YdKhQHaEC?pid=ImgDet&w=474&h=258&rs=1', name: 'lake water' },



  { src: 'https://wallup.net/wp-content/uploads/2019/10/336103-sky-clouds-scenery-sunset-beautiful-nature-landscape.jpg', name: 'sunset tree lake ' },

  { src: 'https://preview.redd.it/2ndmx9ziaqf01.jpg?width=640&crop=smart&auto=webp&s=d9a7d24ac622a74274de0f77773573cd5aef86ac', name: 'sun nature lake' },
  { src: 'https://wallpapercave.com/wp/wp9277430.jpg', name: 'birds nature life ' },

  { src: 'https://th.bing.com/th/id/OIP.k7yH80SdjSvGEp9xQd-SywHaEK?pid=ImgDet&w=474&h=266&rs=1', name: 'trees forest' },
  { src: 'https://th.bing.com/th/id/OIP.iHQ0isJ8cCmBo1O7HmJFkQHaE_?rs=1&pid=ImgDetMain', name: 'city water tree night ' },
  { src: 'https://th.bing.com/th/id/R.c76f7b6d86ee12c1f15a858d88d023cf?rik=yrBOZ8wvyEVcXg&riu=http%3a%2f%2fwallpapercave.com%2fwp%2fLcTr24B.jpg&ehk=W0aqK1oHqrDKLcTwZ3k04sIOeYvKcQCWbI8cIRN1Hhc%3d&risl=&pid=ImgRaw&r=0', name: 'water tree forest lake' },
  { src: 'https://th.bing.com/th/id/OIP.ec9RAfEr94fZ5-hSj3Y20wHaEo?w=2048&h=1280&rs=1&pid=ImgDetMain', name: 'forest water lake forest nature' },


  { src: 'https://th.bing.com/th/id/OIP.VHusBfOGcfIVEp5iGupYFQHaEo?pid=ImgDet&w=474&h=296&rs=1', name: 'birds nature' },

  { src: 'https://th.bing.com/th/id/R.926142ec10e94218d44ab20f8f839208?rik=e8k348Ky3%2bdDIA&riu=http%3a%2f%2fpixelstalk.net%2fwp-content%2fuploads%2f2016%2f08%2fSunset-Beaches-Backgrounds.jpg&ehk=50QURJIXrlDdCSaOUTLwBe%2flUpzQvPdOPk6HVps%2bvYc%3d&risl=1&pid=ImgRaw&r=0', name: 'beach water lake sun nature' },
  { src: 'https://th.bing.com/th/id/OIP.cUsprnN0L3YZGICrk37VAQHaEK?rs=1&pid=ImgDetMain', name: 'forest nature tree green' },
  { src: 'https://wallpapercave.com/wp/wp5440804.jpg', name: 'love night person people night' },
  { src: 'https://th.bing.com/th/id/OIP.3ygl4YCcKCiXQJkbugbP4gHaEo?w=1600&h=1000&rs=1&pid=ImgDetMain', name: 'snow mountain him'},

  { src: 'https://th.bing.com/th/id/OIP.gm9Qkm3QKlXezT64-PBG0gHaEK?rs=1&pid=ImgDetMain', name: 'sun water lake nature ' },

  { src: 'https://th.bing.com/th/id/R.a1ec25efd0cc7c12806e53f52ffd00bb?rik=gmd2xlBKcSUyXQ&riu=http%3a%2f%2fwallpapercave.com%2fwp%2f0ba9rJK.jpg&ehk=SnAULC481UvWLjD%2f%2fmzjIb%2bqusENKYDuPxtxTBy80%2fU%3d&risl=&pid=ImgRaw&r=0', name: 'city buildings set ' },
  { src: 'https://th.bing.com/th/id/OIP.ZqWmzWPlUF1dQ2XEcqsyTgHaEK?rs=1&pid=ImgDetMain', name: 'bridge water night city ' },
  { src: 'https://i.pinimg.com/originals/07/b9/8a/07b98a7084238c04b85f6c0ac4407944.jpg', name: 'snow mountain him ice' },
  { src: 'https://www.wallpaperbetter.com/wallpaper/999/359/608/happiness-people-laptop-backgrounds-720P-wallpaper.jpg', name: 'people happy enjoy life person' },

  { src: 'https://www.3blmedia.com/sites/www.3blmedia.com/files/images/tree_country_road_iStock-500891249.jpg', name: 'tree nature Tree forest Forest' },  



  { src: 'https://thumbs.dreamstime.com/b/black-people-vibrant-colors-background-matters-concept-ai-generated-273350954.jpg', name: 'people art person' },
  { src: 'https://wallpapercave.com/wp/wp3286696.jpg', name: 'birds nature forest ' },
  { src: 'https://wallpaperaccess.com/full/2560244.jpg', name: 'moon night' },

  { src: 'https://wallup.net/wp-content/uploads/2019/09/251780-coast-cityscapes-chicago-buildings-skyscrapers-lake-michigan-hdr-photography-great-lakes-beaches.jpg', name: 'city sun cloud' },

]   

const App = () => {
  const [selectedImageIndex, setSelectedImageIndex] = useState(null);
  const [filter, setFilter] = useState('');

  const openModal = (index) => {
    setSelectedImageIndex(index);
  };

  const closeModal = () => {
    setSelectedImageIndex(null);
  };

  const showNextImage = (e) => {
    e.stopPropagation();
    setSelectedImageIndex((prevIndex) => (prevIndex + 1) % images.length);
  };

  const showPrevImage = (e) => {
    e.stopPropagation();
    setSelectedImageIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length);
  };

  const handleFilterChange = (e) => {
    setFilter(e.target.value);
  };

  const filteredImages = images.filter(image => image.name.toLowerCase().includes(filter.toLowerCase()));

  return (
    <div className="gallery-container">
      <div className="filter-container">
        <input type="text" className="searchbar" value={filter} onChange={handleFilterChange} placeholder="Search an image" />
      </div>
      <div className="gallery-grid">
        {filteredImages.map((image, index) => (
          <div key={index} className="gallery-item" onClick={() => openModal(index)}>
            <img src={image.src} alt={image.name} />
          </div>
        ))}
      </div>

      {selectedImageIndex !== null && (
        <div className="modal" onClick={closeModal}>
          <span className="close" onClick={closeModal}>&times;</span>
          <span className="navigation prev" onClick={showPrevImage}>{"<"}</span>
          <img className="modal-content" src={filteredImages[selectedImageIndex].src} alt="Selected" />
          <span className="navigation next" onClick={showNextImage}>{">"}</span>
        </div>
      )}
    </div>
  );
};

const rootElement = document.getElementById('root');
ReactDOM.render(<App />, rootElement);
